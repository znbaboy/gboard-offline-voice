package app.template.patches.gboard.voice

import app.morphe.patcher.Fingerprint
import app.morphe.patcher.extensions.InstructionExtensions.addInstruction
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.ApkFileType
import app.morphe.patcher.patch.AppTarget
import app.morphe.patcher.patch.Compatibility
import app.morphe.patcher.patch.PatchException
import app.morphe.patcher.patch.classDefBy
import app.morphe.patcher.patch.classDefForEach
import app.morphe.patcher.patch.mutableClassDefBy
import app.morphe.patcher.patch.patch
import app.morphe.patcher.patch.resourceXml
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.AccessFlags
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.ClassDef
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

val COMPATIBILITY_GBOARD = Compatibility(
    name = "Gboard",
    packageName = "com.google.android.inputmethod.latin",
    apkFileType = ApkFileType.APK,
    appIconColor = 0x4285F4,
    targets = listOf(
        AppTarget(version = "18.6.3.1002251336-release-arm64-v8a"),
        AppTarget(version = null, isExperimental = true),
    ),
)

// FallbackOnDeviceRecognitionProvider.maybeScheduleAutoPackDownload(LanguageTag)
object AutoPackDownloadFingerprint : Fingerprint(
    returnType = "V",
    parameters = listOf("L"),
    strings = listOf("maybeScheduleAutoPackDownload() for language tag %s"),
)

// Voice flag definitions (static initializer).
object VoiceFlagsFingerprint : Fingerprint(
    name = "<clinit>",
    strings = listOf("allow_metered_small_speech_pack_downloads", "enable_fallback_ondevice_recognizer"),
)

// SpeechRecognitionFactory.getSpeechRecognizerType(Context, SessionParams)
object RecognizerTypeFingerprint : Fingerprint(
    returnType = "L",
    parameters = listOf("Landroid/content/Context;", "L"),
    strings = listOf("getSpeechRecognizerType", "[Jetson] Using NEW_S3 with Jetson S3 routing key."),
)

private fun Instruction.string(): String? =
    ((this as? ReferenceInstruction)?.reference as? StringReference)?.string

private fun Instruction.method(): MethodReference? =
    (this as? ReferenceInstruction)?.reference as? MethodReference

private fun Method.sig() = name + parameterTypes.joinToString("") + returnType

private fun MethodReference.sig() = name + parameterTypes.joinToString("") + returnType

private fun MethodReference.isAvailabilityCheck() =
    returnType == "Z" && parameterTypes.size == 2 && parameterTypes[0].toString() == "Landroid/content/Context;"

private fun Method.freeLocals(): Int {
    val params = parameterTypes.sumOf { p -> if (p.toString() == "J" || p.toString() == "D") 2 else 1 } +
        if (AccessFlags.STATIC.isSet(accessFlags)) 0 else 1
    return (implementation?.registerCount ?: 0) - params
}

// SpeechPackManager.syncPacks(LanguageTag): Gboard's background download (charging-only).
object SyncPacksFingerprint : Fingerprint(
    returnType = "V",
    parameters = listOf("L"),
    strings = listOf("syncPacks()"),
)

// SpeechPackManager.syncPacksNow(LanguageTag): Gboard's immediate download (no charging/Wi-Fi requirement).
object SyncPacksNowFingerprint : Fingerprint(
    returnType = "V",
    parameters = listOf("L"),
    strings = listOf("syncPacksNow()"),
)

// OnDeviceDownloadNowReceiver.onReceive(): Gboard's own "download now" (cancel queued downloads, then sync now).
object DownloadNowReceiverFingerprint : Fingerprint(
    returnType = "V",
    parameters = listOf("Landroid/content/Context;", "Landroid/content/Intent;"),
    strings = listOf("cancelRunningDownloads()"),
)

private const val UI_EXT = "Lapp/template/extension/gboard/OfflineVoicePatch;"
private const val UI_ACTIVITY = "app.template.extension.gboard.OfflineVoiceActivity"

@Suppress("unused")
val downloadOfflineVoiceModelPatch = patch(
    name = "Download offline voice model",
    description = "Adds \"Offline voice model\" to Gboard's Voice typing settings: pick Full (85 MB, default) or " +
        "Standard (12 MB), download it with a button, and see when it is downloaded and active.",
    default = true,
) {
    compatibleWith(COMPATIBILITY_GBOARD)
    extendWith("extensions/extension.mpe")

    execute {
        // --- Resolve Gboard internals the settings screen needs (names are obfuscated per build).
        val canHandle = FallbackCanHandleFingerprint.originalMethod
        val canHandleInsns = canHandle.implementation!!.instructions.toList()
        val enUs = canHandleInsns.firstNotNullOfOrNull { insn ->
            ((insn as? ReferenceInstruction)?.reference as? FieldReference)?.takeIf {
                insn.opcode == Opcode.SGET_OBJECT && it.type == it.definingClass
            }
        } ?: throw PatchException("en-US language constant not found")
        val languageType = enUs.type

        // SpeechPackManager.isPackAvailable(LanguageTag) and the provider field holding the manager.
        val availableIndex = canHandleInsns.indexOfFirst { insn ->
            insn.opcode == Opcode.INVOKE_VIRTUAL && insn.method()?.let {
                it.returnType == "Z" && it.definingClass != languageType &&
                    it.parameterTypes.map(CharSequence::toString) == listOf(languageType)
            } == true
        }
        if (availableIndex < 0) throw PatchException("Pack availability check not found")
        val isAvailable = canHandleInsns[availableIndex].method()!!
        val packManagerField = (availableIndex downTo 0).firstNotNullOfOrNull { i ->
            ((canHandleInsns[i] as? ReferenceInstruction)?.reference as? FieldReference)?.takeIf {
                canHandleInsns[i].opcode == Opcode.IGET_OBJECT && it.type == isAvailable.definingClass
            }
        } ?: throw PatchException("Pack manager field not found")

        // SpeechPackManager.getPackDirectory(LanguageTag)
        val packDir = FallbackGetRecognizerFingerprint.originalMethod.implementation!!.instructions
            .firstNotNullOfOrNull { insn ->
                insn.method()?.takeIf {
                    insn.opcode == Opcode.INVOKE_VIRTUAL && it.returnType == "Ljava/io/File;" &&
                        it.parameterTypes.map(CharSequence::toString) == listOf(languageType)
                }
            } ?: throw PatchException("Speech pack lookup not found")

        // Static holder of the fallback provider: read inside isFallbackOnDeviceAvailable().
        val typeInsns = RecognizerTypeFingerprint.originalMethod.implementation!!.instructions.toList()
        val offlineCheck = typeInsns.mapNotNull { insn ->
            insn.takeIf { it.opcode == Opcode.INVOKE_STATIC }?.method()?.takeIf { it.isAvailabilityCheck() }
        }.lastOrNull() ?: throw PatchException("Offline recognizer check not found")
        val offlineCheckMethod = classDefBy(offlineCheck.definingClass).methods.first { it.sig() == offlineCheck.sig() }
        val providerField = offlineCheckMethod.implementation!!.instructions.firstNotNullOfOrNull { insn ->
            ((insn as? ReferenceInstruction)?.reference as? FieldReference)
                ?.takeIf { insn.opcode == Opcode.SGET_OBJECT }
        } ?: throw PatchException("Fallback provider holder not found")

        val download = AutoPackDownloadFingerprint.originalMethod

        // Manifest URLs (standard = small pack manifest, full = on-device manifest).
        val clinit = VoiceFlagsFingerprint.originalMethod.implementation!!.instructions.toList()
        fun urlIndexAfter(flagName: String): Int {
            val i = clinit.indexOfFirst { it.string() == flagName }
            if (i < 0) throw PatchException("Flag $flagName not found")
            return (i + 1 until clinit.size).first { clinit[it].string()?.startsWith("https://") == true }
        }
        val fullUrl = clinit[urlIndexAfter("speech_superpacks_manifest_url")].string()!!
        val smallUrlIndex = urlIndexAfter("speech_superpacks_small_lps_manifest_url")

        val standardUrl = clinit[smallUrlIndex].string()!!

        // Gboard's download-now: superpacks.cancelRunningDownloads(superpackName) before syncPacksNow().
        val receiverInsns = DownloadNowReceiverFingerprint.originalMethod.implementation!!.instructions.toList()
        val cancelLog = receiverInsns.indexOfFirst { it.string() == "cancelRunningDownloads()" }
        val cancelIndex = (cancelLog until receiverInsns.size).firstOrNull { i ->
            receiverInsns[i].opcode == Opcode.INVOKE_INTERFACE && receiverInsns[i].method()?.let {
                // superpacks.cancelRunningDownloads(name) returns a future; log calls return void.
                it.returnType.startsWith("L") &&
                    it.parameterTypes.map(CharSequence::toString) == listOf("Ljava/lang/String;")
            } == true
        } ?: throw PatchException("cancelRunningDownloads call not found")
        val cancel = receiverInsns[cancelIndex].method()!!
        fun fieldBefore(type: String) = (cancelIndex downTo cancelLog).firstNotNullOfOrNull { i ->
            ((receiverInsns[i] as? ReferenceInstruction)?.reference as? FieldReference)?.takeIf {
                receiverInsns[i].opcode == Opcode.IGET_OBJECT && it.type == type &&
                    it.definingClass == isAvailable.definingClass
            }
        }
        val superpacksField = fieldBefore(cancel.definingClass) ?: throw PatchException("Superpacks field not found")
        val superpackNameField = fieldBefore("Ljava/lang/String;") ?: throw PatchException("Superpack name field not found")

        fun cls(t: String) = t.removePrefix("L").removeSuffix(";").replace('/', '.')
        val spec = listOf(
            "providerHolder" to cls(providerField.definingClass),
            "providerField" to providerField.name,
            "download" to download.name,
            "languageClass" to cls(languageType),
            "enUs" to enUs.name,
            "packManagerField" to packManagerField.name,
            "isAvailable" to isAvailable.name,
            "packDir" to packDir.name,
            "syncNow" to SyncPacksNowFingerprint.originalMethod.name,
            "fullUrl" to fullUrl,
            "standardUrl" to standardUrl,
            "superpacksInterface" to cls(cancel.definingClass),
            "superpacksField" to superpacksField.name,
            "superpackNameField" to superpackNameField.name,
            "cancel" to cancel.name,
        ).joinToString("|") { (k, v) -> "$k=$v" }
        if (spec.contains('"') || spec.contains('\\')) throw PatchException("Unexpected characters in bridge spec")

        // --- Bake the spec into the extension.
        mutableClassDefBy(UI_EXT).methods.first { it.name == "spec" }.apply {
            addInstructions(0, "const-string v0, \"$spec\"\nreturn-object v0")
        }

        // --- 1) Drop the "used voice typing at least 5 times recently" requirement.
        AutoPackDownloadFingerprint.method.apply {
            val insns = implementation!!.instructions.toList()
            val index = insns.indexOfFirst {
                it.opcode == Opcode.CONST_WIDE_16 && (it as WideLiteralInstruction).wideLiteral == 5L
            }
            if (index < 0) throw PatchException("Voice usage threshold not found")
            val register = (insns[index] as OneRegisterInstruction).registerA
            replaceInstruction(index, "const-wide/16 v$register, 0x0")
        }

        // --- 2) Model choice: wherever Gboard turns the pack manifest flag into a URL, swap in the
        //         chosen model's manifest. Read-time, so switching models needs no restart.
        val urlMapField = AutoPackDownloadFingerprint.originalMethod.implementation!!.instructions.toList().let { insns ->
            insns.indices.firstNotNullOfOrNull { i ->
                ((insns[i] as? ReferenceInstruction)?.reference as? FieldReference)?.takeIf {
                    insns[i].opcode == Opcode.SGET_OBJECT &&
                        (i + 1 until minOf(i + 4, insns.size)).any { j ->
                            insns[j].method()?.let { m -> m.name == "get" && m.returnType == "Ljava/lang/Object;" } == true
                        }
                }
            }
        } ?: throw PatchException("Manifest URL map not found")

        val urlReaders = mutableListOf<ClassDef>()
        classDefForEach { cd ->
            if (cd.methods.any { m ->
                    m.implementation?.instructions?.any { i ->
                        i.opcode == Opcode.SGET_OBJECT &&
                            ((i as ReferenceInstruction).reference as FieldReference).let {
                                it.definingClass == urlMapField.definingClass && it.name == urlMapField.name
                            }
                    } == true
                }
            ) {
                urlReaders += cd
            }
        }
        var urlHooks = 0
        urlReaders.forEach { cd ->
            mutableClassDefBy(cd).methods.forEach { m ->
                val insns = m.implementation?.instructions?.toList() ?: return@forEach
                insns.indices.filter { i ->
                    insns[i].opcode == Opcode.SGET_OBJECT &&
                        ((insns[i] as ReferenceInstruction).reference as FieldReference).let {
                            it.definingClass == urlMapField.definingClass && it.name == urlMapField.name
                        }
                }.mapNotNull { s ->
                    (s until minOf(s + 10, insns.size)).firstOrNull { j ->
                        insns[j].opcode == Opcode.CHECK_CAST &&
                            ((insns[j] as ReferenceInstruction).reference.toString() == "Ljava/lang/String;")
                    }
                }.sortedDescending().forEach { cast ->
                    val reg = (insns[cast] as OneRegisterInstruction).registerA
                    m.addInstructions(
                        cast + 1,
                        """
                            invoke-static/range {v$reg .. v$reg}, $UI_EXT->resolveManifestUrl(Ljava/lang/String;)Ljava/lang/String;
                            move-result-object v$reg
                        """,
                    )
                    urlHooks++
                }
            }
        }
        if (urlHooks == 0) throw PatchException("Manifest URL reads not found")

        // --- 3) Mobile data: allowed for a while after the user taps Download (Wi-Fi only otherwise).
        val nameIndex = clinit.indexOfFirst { it.string() == "allow_metered_small_speech_pack_downloads" }
        val flagField = clinit.drop(nameIndex).firstNotNullOfOrNull { insn ->
            ((insn as? ReferenceInstruction)?.reference as? FieldReference)
                ?.takeIf { insn.opcode == Opcode.SPUT_OBJECT }
        } ?: throw PatchException("Metered download flag field not found")
        fun FieldReference.matches(other: FieldReference) =
            definingClass == other.definingClass && name == other.name

        val readers = mutableListOf<ClassDef>()
        classDefForEach { cd ->
            if (cd.type != flagField.definingClass && cd.methods.any { m ->
                    m.implementation?.instructions?.any { i ->
                        i.opcode == Opcode.SGET_OBJECT &&
                            ((i as ReferenceInstruction).reference as FieldReference).matches(flagField)
                    } == true
                }
            ) {
                readers += cd
            }
        }
        var gated = 0
        readers.forEach { cd ->
            mutableClassDefBy(cd).methods.forEach { m ->
                val insns = m.implementation?.instructions?.toList() ?: return@forEach
                insns.indices.filter { i ->
                    insns[i].opcode == Opcode.SGET_OBJECT &&
                        ((insns[i] as ReferenceInstruction).reference as FieldReference).matches(flagField)
                }.mapNotNull { s ->
                    val unbox = (s until minOf(s + 8, insns.size)).firstOrNull { j ->
                        insns[j].method()?.let {
                            it.definingClass == "Ljava/lang/Boolean;" && it.name == "booleanValue"
                        } == true
                    } ?: return@mapNotNull null
                    (unbox + 1).takeIf { it < insns.size && insns[it].opcode == Opcode.MOVE_RESULT }
                }.sortedDescending().forEach { moveResult ->
                    val reg = (insns[moveResult] as OneRegisterInstruction).registerA
                    m.addInstructions(
                        moveResult + 1,
                        """
                            invoke-static {}, $UI_EXT->allowMobileData()Z
                            move-result v$reg
                        """,
                    )
                    gated++
                }
            }
        }
        if (gated == 0) throw PatchException("Metered download flag read not found")

        // --- 3b) While a manual download is pending, every pack sync runs like syncPacksNow
        //         (no charging / Wi-Fi requirement). Hooked at the entry of the shared sync method
        //         SpeechPackManager.sync(foreground, wifiOnly, chargingOnly, languageTag), which both
        //         syncPacks() and syncPacksNow() call, so no branch can skip it.
        val syncCall = SyncPacksFingerprint.originalMethod.implementation!!.instructions.firstNotNullOfOrNull { insn ->
            insn.method()?.takeIf {
                insn.opcode == Opcode.INVOKE_DIRECT && it.returnType == "V" &&
                    it.parameterTypes.map(CharSequence::toString).let { p ->
                        p.size == 4 && p[0] == "Z" && p[1] == "Z" && p[2] == "Z"
                    }
            }
        } ?: throw PatchException("Pack sync call not found")
        mutableClassDefBy(syncCall.definingClass).methods.first { it.sig() == syncCall.sig() }.apply {
            if (AccessFlags.STATIC.isSet(accessFlags) || freeLocals() < 1) {
                throw PatchException("Unexpected pack sync method shape")
            }
            addInstructionsWithLabels(
                0,
                """
                    invoke-static {}, $UI_EXT->allowMobileData()Z
                    move-result v0
                    if-eqz v0, :mpkeep
                    const/4 p1, 0x1
                    const/4 p2, 0x0
                    const/4 p3, 0x0
                """,
                ExternalLabel("mpkeep", getInstruction(0)),
            )
        }

        // --- 4) Settings entry under Voice typing + the screen it opens.
        resourceXml("AndroidManifest.xml").use { manifest ->
            val packageName = manifest.elements("manifest").first().attribute("package")
                ?: "com.google.android.inputmethod.latin"
            manifest.elements("application").first().appendChild("activity") {
                setAttribute("android:name", UI_ACTIVITY)
                setAttribute("android:exported", "false")
                setAttribute("android:label", "Offline voice model")
                setAttribute("android:theme", "@android:style/Theme.DeviceDefault.Light")
                setAttribute("android:configChanges", "orientation|screenSize|screenLayout|smallestScreenSize|uiMode")
            }
            var added = 0
            listOf("res/xml/setting_voice.xml", "res/xml/setting_traditional_voice.xml").forEach { path ->
                resourceXml(path).use { xml ->
                    val screen = xml.elements("PreferenceScreen").first()
                    screen.appendChild("Preference") {
                        setAttribute("android:key", "offline_voice_model_settings")
                        setAttribute("android:persistent", "false")
                        setAttribute("android:title", "Offline voice model")
                        setAttribute("android:summary", "Download and check Gboard's on-device voice model")
                        appendChild("intent") {
                            setAttribute("android:targetPackage", packageName)
                            setAttribute("android:targetClass", UI_ACTIVITY)
                        }
                    }
                    added++
                }
            }
            if (added == 0) throw PatchException("Voice settings screens not found")
        }
    }
}

@Suppress("unused")
val preferOfflineVoiceModelPatch = patch(
    name = "Prefer offline voice model",
    description = "Uses Gboard's offline voice model whenever it is downloaded, instead of Google's online " +
        "recognizer (which needs Google Play services).",
    default = true,
) {
    compatibleWith(COMPATIBILITY_GBOARD)

    execute {
        val insns = RecognizerTypeFingerprint.originalMethod.implementation!!.instructions.toList()
        val logIndex = insns.indexOfFirst { it.string() == "[Jetson] Using NEW_S3 with Jetson S3 routing key." }

        // Online (NEW_S3) availability check: the last static Context check before the NEW_S3 log.
        val serverCheck = (logIndex downTo 0).firstNotNullOfOrNull { i ->
            insns[i].takeIf { it.opcode == Opcode.INVOKE_STATIC }?.method()?.takeIf { it.isAvailabilityCheck() }
        } ?: throw PatchException("Server recognizer check not found")

        // Offline (fallback on-device) availability check: the last such check in the method.
        val offlineCheck = insns.mapNotNull { insn ->
            insn.takeIf { it.opcode == Opcode.INVOKE_STATIC }?.method()?.takeIf { it.isAvailabilityCheck() }
        }.lastOrNull() ?: throw PatchException("Offline recognizer check not found")

        if (serverCheck.definingClass == offlineCheck.definingClass && serverCheck.sig() == offlineCheck.sig()) {
            throw PatchException("Recognizer checks are ambiguous")
        }

        // The online check reports "unavailable" whenever the offline model can handle the session.
        mutableClassDefBy(serverCheck.definingClass).methods.first { it.sig() == serverCheck.sig() }.apply {
            if (!AccessFlags.STATIC.isSet(accessFlags) || freeLocals() < 1) {
                throw PatchException("Unexpected server recognizer check shape")
            }
            val params = offlineCheck.parameterTypes.joinToString("")
            addInstructionsWithLabels(
                0,
                """
                    invoke-static {p0, p1}, ${offlineCheck.definingClass}->${offlineCheck.name}($params)Z
                    move-result v0
                    if-eqz v0, :mpskip
                    const/4 v0, 0x0
                    return v0
                """,
                ExternalLabel("mpskip", getInstruction(0)),
            )
        }
    }
}

private const val EXT = "Lapp/template/extension/gboard/OfflineVoicePatch;"

// FallbackOnDeviceRecognitionProvider.canHandle(Context, SessionParams)
object FallbackCanHandleFingerprint : Fingerprint(
    returnType = "Z",
    parameters = listOf("Landroid/content/Context;", "L"),
    strings = listOf("canHandle() : Only en-us is supported for fallback on-device recognition."),
)

// FallbackOnDeviceRecognitionProvider.getRecognizer(Context, SessionParams)
object FallbackGetRecognizerFingerprint : Fingerprint(
    parameters = listOf("Landroid/content/Context;", "L"),
    strings = listOf("newRecognizer() : No speech pack."),
)

@Suppress("unused")
val offlineVoiceAllEnglishPatch = patch(
    name = "Offline voice for all English variants",
    description = "Uses the en-US offline voice model for any English keyboard language " +
        "(English Canada, UK, India, Australia, ...). Gboard normally allows English (US) only.",
    default = true,
) {
    compatibleWith(COMPATIBILITY_GBOARD)
    extendWith("extensions/extension.mpe")

    execute {
        val canHandle = FallbackCanHandleFingerprint.method
        val canHandleInsns = canHandle.implementation!!.instructions.toList()

        // en-US constant: LanguageTag.EN_US read inside canHandle().
        val enUs = canHandleInsns.firstNotNullOfOrNull { insn ->
            ((insn as? ReferenceInstruction)?.reference as? FieldReference)?.takeIf {
                insn.opcode == Opcode.SGET_OBJECT && it.type == it.definingClass
            }
        } ?: throw PatchException("en-US language constant not found")
        val languageType = enUs.type
        val enUsField = "${enUs.definingClass}->${enUs.name}:${enUs.type}"

        // 1) canHandle(): LanguageTag.equals(EN_US) -> sameLanguage() so en-CA etc. pass.
        val equalsCalls = canHandleInsns.indices.filter { i ->
            insns@ run {
                val m = canHandleInsns[i].method() ?: return@run false
                canHandleInsns[i].opcode == Opcode.INVOKE_VIRTUAL &&
                    m.definingClass == languageType && m.name == "equals" && m.returnType == "Z"
            }
        }
        if (equalsCalls.isEmpty()) throw PatchException("Language checks not found in canHandle()")
        equalsCalls.sortedDescending().forEach { i ->
            val call = canHandleInsns[i] as com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
            if (call.registerC > 15 || call.registerD > 15) throw PatchException("Unexpected register layout")
            canHandle.replaceInstruction(
                i,
                "invoke-static {v${call.registerC}, v${call.registerD}}, $EXT->sameLanguage(Ljava/lang/Object;Ljava/lang/Object;)Z",
            )
        }

        val mapToEnUs = """
            invoke-static/range {p1 .. p1}, $EXT->isEnglish(Ljava/lang/Object;)Z
            move-result v0
            if-eqz v0, :mpskip
            sget-object p1, $enUsField
        """

        fun Method.requireLanguageParam(what: String) {
            if (parameterTypes.size != 1 || parameterTypes[0].toString() != languageType ||
                AccessFlags.STATIC.isSet(accessFlags) || freeLocals() < 1
            ) {
                throw PatchException("Unexpected $what signature")
            }
        }

        // 2) Download scheduling: schedule the en-US pack for any English language.
        AutoPackDownloadFingerprint.method.apply {
            requireLanguageParam("download scheduler")
            addInstructionsWithLabels(0, mapToEnUs, ExternalLabel("mpskip", getInstruction(0)))
        }

        // 3) Pack lookup used to build the recognizer: resolve English variants to the en-US pack.
        val packLookup = FallbackGetRecognizerFingerprint.originalMethod.implementation!!.instructions
            .firstNotNullOfOrNull { insn ->
                insn.method()?.takeIf {
                    insn.opcode == Opcode.INVOKE_VIRTUAL && it.returnType == "Ljava/io/File;" &&
                        it.parameterTypes.map(CharSequence::toString) == listOf(languageType)
                }
            } ?: throw PatchException("Speech pack lookup not found")
        mutableClassDefBy(packLookup.definingClass).methods.first { it.sig() == packLookup.sig() }.apply {
            requireLanguageParam("speech pack lookup")
            addInstructionsWithLabels(0, mapToEnUs, ExternalLabel("mpskip", getInstruction(0)))
        }
    }
}
