package app.template.extension.gboard;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Bridge between the patch and Gboard's own offline voice code. Gboard's class and member
 * names are obfuscated, so the patch resolves them at patch time and bakes them into spec().
 */
@SuppressWarnings("unused")
public final class OfflineVoicePatch {
    static final String TAG = "GboardOfflineVoice";

    static final String MODEL_STANDARD = "standard";
    static final String MODEL_FULL = "full";

    private static final String PREFS = "offline_voice_model";
    private static final String KEY_MODEL = "model";
    private static final String KEY_REQUESTED_AT = "requested_at";
    private static final long MOBILE_DATA_WINDOW_MS = 3L * 60 * 60 * 1000;
    // The full model's encoder is ~76 MB, the standard one ~8.5 MB.
    private static final long FULL_ENCODER_MIN_BYTES = 40L * 1024 * 1024;

    private static volatile Map<String, String> spec;

    private OfflineVoicePatch() {
    }

    /** Replaced by the patch with the resolved Gboard names. */
    public static String spec() {
        return "";
    }

    private static Map<String, String> specMap() {
        Map<String, String> m = spec;
        if (m == null) {
            m = new HashMap<>();
            for (String kv : spec().split("\\|")) {
                int i = kv.indexOf('=');
                if (i > 0) m.put(kv.substring(0, i), kv.substring(i + 1));
            }
            spec = m;
        }
        return m;
    }

    // ---------------------------------------------------------------- English variants

    /** True for any English language tag (en, en-CA, en-GB, en_IN, ...). */
    public static boolean isEnglish(Object languageTag) {
        if (languageTag == null) return false;
        String tag = languageTag.toString();
        if (tag == null) return false;
        tag = tag.toLowerCase(Locale.ROOT);
        return tag.equals("en") || tag.startsWith("en-") || tag.startsWith("en_");
    }

    /** Replacement for LanguageTag.equals() in the offline provider: all English variants match. */
    public static boolean sameLanguage(Object a, Object b) {
        if (a == null) return b == null;
        return a.equals(b) || (isEnglish(a) && isEnglish(b));
    }

    // ---------------------------------------------------------------- Hooks

    /**
     * Injected wherever Gboard turns a pack manifest flag into a URL. Swaps the small-pack
     * manifest for the full one when the user picked Full; every other URL passes through.
     */
    public static String resolveManifestUrl(String url) {
        Map<String, String> s = specMap();
        if (url == null || !url.equals(s.get("standardUrl"))) return url;
        String full = s.get("fullUrl");
        return MODEL_FULL.equals(chosenModel(appContext())) && full != null ? full : url;
    }

    /** Injected where Gboard reads allow_metered_small_speech_pack_downloads. */
    public static boolean allowMobileData() {
        Context c = appContext();
        if (c == null) return false;
        long at = prefs(c).getLong(KEY_REQUESTED_AT, 0);
        return at > 0 && System.currentTimeMillis() - at < MOBILE_DATA_WINDOW_MS;
    }

    // ---------------------------------------------------------------- Used by the settings screen

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String chosenModel(Context c) {
        // Full is the default; Standard only when the user picked it.
        if (c == null) return MODEL_FULL;
        return MODEL_STANDARD.equals(prefs(c).getString(KEY_MODEL, MODEL_FULL)) ? MODEL_STANDARD : MODEL_FULL;
    }

    static void setChosenModel(Context c, String model) {
        prefs(c).edit().putString(KEY_MODEL, model).commit();
    }

    static long requestedAt(Context c) {
        return prefs(c).getLong(KEY_REQUESTED_AT, 0);
    }

    static void markRequested(Context c) {
        prefs(c).edit().putLong(KEY_REQUESTED_AT, System.currentTimeMillis()).commit();
    }

    /** Gboard's offline voice provider, or null if the voice module isn't loaded yet. */
    static Object provider() throws Exception {
        Map<String, String> s = specMap();
        Class<?> holder = Class.forName(s.get("providerHolder"), true, OfflineVoicePatch.class.getClassLoader());
        Field f = holder.getField(s.get("providerField"));
        return f.get(null);
    }

    private static Object enUs() throws Exception {
        Map<String, String> s = specMap();
        Class<?> lang = Class.forName(s.get("languageClass"), true, OfflineVoicePatch.class.getClassLoader());
        return lang.getField(s.get("enUs")).get(null);
    }

    private static Object packManager(Object provider) throws Exception {
        return field(provider, specMap().get("packManagerField"));
    }

    /**
     * Asks Gboard to download the offline pack now, through its own syncPacksNow():
     * registers the chosen manifest and syncs without waiting for Wi-Fi or a charger.
     */
    static void requestDownload(Object provider) throws Exception {
        Map<String, String> s = specMap();
        Object pm = packManager(provider);
        Object tag = enUs();

        // Step 1, as Gboard's own download-now does: cancel queued/running downloads for this pack,
        // otherwise the request waits behind an older background (charging-only) job.
        try {
            Object superpacks = field(pm, s.get("superpacksField"));
            Object name = field(pm, s.get("superpackNameField"));
            Class<?> iface = Class.forName(s.get("superpacksInterface"), true, OfflineVoicePatch.class.getClassLoader());
            Object pending = iface.getMethod(s.get("cancel"), String.class).invoke(superpacks, name);
            if (pending instanceof Future) ((Future<?>) pending).get(15, TimeUnit.SECONDS);
        } catch (Throwable t) {
            Log.w(TAG, "cancelRunningDownloads failed", t);
        }

        // Step 2: syncPacksNow() registers the chosen manifest and downloads without waiting.
        findMethod(pm.getClass(), s.get("syncNow"), tag.getClass()).invoke(pm, tag);
    }

    private static Object field(Object target, String name) throws Exception {
        for (Class<?> c = target.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(target);
            } catch (NoSuchFieldException ignored) {
            }
        }
        throw new NoSuchFieldException(target.getClass().getName() + "." + name);
    }

    /** True if Gboard reports the en-US offline pack as downloaded. */
    static boolean isDownloaded(Object provider) throws Exception {
        Object pm = packManager(provider);
        Object tag = enUs();
        Object r = findMethod(pm.getClass(), specMap().get("isAvailable"), tag.getClass()).invoke(pm, tag);
        return Boolean.TRUE.equals(r);
    }

    /** MODEL_FULL / MODEL_STANDARD for the pack Gboard would load, or null if none. */
    static String installedModel(Object provider) throws Exception {
        Object pm = packManager(provider);
        Object tag = enUs();
        Object dir = findMethod(pm.getClass(), specMap().get("packDir"), tag.getClass()).invoke(pm, tag);
        if (!(dir instanceof File)) return null;
        File encoder = new File((File) dir, "encoder.part_1.tflite");
        if (!encoder.exists()) return null;
        return encoder.length() >= FULL_ENCODER_MIN_BYTES ? MODEL_FULL : MODEL_STANDARD;
    }

    private static Method findMethod(Class<?> cls, String name, Class<?> param) throws NoSuchMethodException {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                Class<?>[] ps = m.getParameterTypes();
                if (m.getName().equals(name) && ps.length == 1 && ps[0].isAssignableFrom(param)) {
                    m.setAccessible(true);
                    return m;
                }
            }
        }
        throw new NoSuchMethodException(cls.getName() + "." + name);
    }

    @SuppressLint({"PrivateApi", "DiscouragedPrivateApi"})
    static Context appContext() {
        try {
            Object app = Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
            return (Context) app;
        } catch (Throwable t) {
            Log.w(TAG, "no application context", t);
            return null;
        }
    }
}
