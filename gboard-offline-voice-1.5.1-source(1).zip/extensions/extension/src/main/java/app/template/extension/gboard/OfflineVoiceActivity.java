package app.template.extension.gboard;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** "Offline voice model" screen opened from Gboard's Voice typing settings. */
public final class OfflineVoiceActivity extends Activity {
    private static final long POLL_MS = 2000;
    private static final long RETRY_AFTER_MS = 5L * 60 * 1000;
    private static final long REQUEST_VALID_MS = 3L * 60 * 60 * 1000;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private TextView status;
    private TextView detail;
    private ProgressBar spinner;
    private RadioButton standardOption;
    private RadioButton fullOption;
    private Button action;
    private boolean resumed;
    private State state = new State();

    private static final class State {
        boolean moduleReady;
        boolean downloaded;
        String installed;   // model Gboard would load, or null
        long requestedAt;
        String error;
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            io.execute(() -> {
                final State s = readState();
                main.post(() -> {
                    state = s;
                    render();
                });
            });
            if (resumed) main.postDelayed(this, POLL_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(Build.VERSION.SDK_INT >= 29
                ? android.R.style.Theme_DeviceDefault_DayNight
                : android.R.style.Theme_DeviceDefault_Light);
        super.onCreate(savedInstanceState);
        setTitle("Offline voice model");
        ActionBar bar = getActionBar();
        if (bar != null) bar.setDisplayHomeAsUpEnabled(true);

        int pad = dp(24);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(pad, dp(16), pad, pad);

        status = text(20, true);
        detail = text(15, false);
        detail.setAlpha(0.75f);
        spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        spinner.setIndeterminate(true);
        spinner.setVisibility(View.GONE);

        TextView modelLabel = text(14, true);
        modelLabel.setText("Model");
        modelLabel.setPadding(0, dp(28), 0, dp(4));

        RadioGroup group = new RadioGroup(this);
        standardOption = new RadioButton(this);
        standardOption.setId(View.generateViewId());
        standardOption.setText("Standard — 12 MB download, faster");
        fullOption = new RadioButton(this);
        fullOption.setId(View.generateViewId());
        fullOption.setText("Full — 85 MB download, most accurate");
        group.addView(standardOption);
        group.addView(fullOption);
        boolean full = OfflineVoicePatch.MODEL_FULL.equals(OfflineVoicePatch.chosenModel(getApplicationContext()));
        (full ? fullOption : standardOption).setChecked(true);
        group.setOnCheckedChangeListener((g, id) -> render());

        action = new Button(this);
        action.setOnClickListener(v -> onAction());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        buttonParams.topMargin = dp(20);

        TextView note = text(13, false);
        note.setAlpha(0.6f);
        note.setPadding(0, dp(28), 0, 0);
        note.setText("Used for English voice typing, online and offline. Say \u201ccomma\u201d, "
                + "\u201cperiod\u201d or \u201cquestion mark\u201d to add punctuation.");

        column.addView(status);
        column.addView(detail);
        column.addView(spinner, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        column.addView(modelLabel);
        column.addView(group);
        column.addView(action, buttonParams);
        column.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.addView(column);
        setContentView(scroll);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        main.removeCallbacks(poll);
        poll.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        main.removeCallbacks(poll);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private State readState() {
        State s = new State();
        Context app = getApplicationContext();
        s.requestedAt = OfflineVoicePatch.requestedAt(app);
        try {
            Object provider = OfflineVoicePatch.provider();
            s.moduleReady = provider != null;
            if (provider != null) {
                s.downloaded = OfflineVoicePatch.isDownloaded(provider);
                s.installed = s.downloaded ? OfflineVoicePatch.installedModel(provider) : null;
            }
        } catch (Throwable t) {
            Log.w(OfflineVoicePatch.TAG, "status failed", t);
            s.error = t.getClass().getSimpleName();
        }
        return s;
    }

    private String selected() {
        return fullOption != null && fullOption.isChecked()
                ? OfflineVoicePatch.MODEL_FULL : OfflineVoicePatch.MODEL_STANDARD;
    }

    private static String label(String model) {
        return OfflineVoicePatch.MODEL_FULL.equals(model) ? "Full" : "Standard";
    }

    private static String size(String model) {
        return OfflineVoicePatch.MODEL_FULL.equals(model) ? "85 MB" : "12 MB";
    }

    private void render() {
        if (status == null) return;
        State s = state;
        String sel = selected();
        long now = System.currentTimeMillis();
        boolean requested = s.requestedAt > 0 && now - s.requestedAt < REQUEST_VALID_MS
                && sel.equals(OfflineVoicePatch.chosenModel(getApplicationContext()));
        boolean selectedReady = s.downloaded && sel.equals(s.installed);
        String other = s.installed != null && !sel.equals(s.installed)
                ? label(s.installed) + " model stays active until then." : "";

        spinner.setVisibility(View.GONE);
        action.setEnabled(true);

        if (s.error != null) {
            status.setText("Couldn't read the model status");
            detail.setText("Open the keyboard once, then come back. (" + s.error + ")");
            action.setText("Download " + label(sel) + " (" + size(sel) + ")");
        } else if (!s.moduleReady) {
            status.setText("Voice typing isn't loaded yet");
            detail.setText("Open the keyboard in any text field once, then come back here.");
            action.setText("Download " + label(sel) + " (" + size(sel) + ")");
            action.setEnabled(false);
        } else if (selectedReady) {
            status.setText("\u2713 " + label(sel) + " model downloaded and active");
            detail.setText("Gboard uses it for English voice typing.");
            action.setText("Check for updates");
        } else if (requested) {
            status.setText("Downloading " + label(sel) + " model\u2026");
            long mins = Math.max(0, (now - s.requestedAt) / 60000);
            detail.setText(size(sel) + " \u00b7 started " + (mins == 0 ? "just now" : mins + " min ago")
                    + ". Keep internet on; this screen updates by itself. "
                    + (s.installed == null ? "Offline voice is unavailable until it finishes." : other));
            spinner.setVisibility(View.VISIBLE);
            boolean stale = now - s.requestedAt > RETRY_AFTER_MS;
            action.setText(stale ? "Retry download" : "Downloading\u2026");
            action.setEnabled(stale);
        } else {
            status.setText(label(sel) + " model not downloaded");
            detail.setText(s.installed != null ? "Currently active: " + label(s.installed) + " model." : "");
            action.setText("Download (" + size(sel) + ")");
        }
    }

    private void onAction() {
        final Context app = getApplicationContext();
        final String sel = selected();
        OfflineVoicePatch.setChosenModel(app, sel);
        OfflineVoicePatch.markRequested(app);

        action.setEnabled(false);
        io.execute(() -> {
            try {
                Object provider = OfflineVoicePatch.provider();
                if (provider != null) OfflineVoicePatch.requestDownload(provider);
            } catch (Throwable t) {
                Log.w(OfflineVoicePatch.TAG, "download request failed", t);
            }
            main.post(() -> {
                main.removeCallbacks(poll);
                poll.run();
            });
        });
    }

    private TextView text(int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_DeviceDefault);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
